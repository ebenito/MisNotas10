﻿using MyNotes10.Models;
using MyNotes10.Views;
using OneDriveSimple;
using SQLite.Net;
using SQLite.Net.Platform.WinRT;
using System;
using System.IO;
using Windows.ApplicationModel;
using Windows.ApplicationModel.Activation;
using Windows.Storage;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Navigation;

namespace MyNotes10
{
    /// <summary>
    /// Proporciona un comportamiento específico de la aplicación para complementar la clase Application predeterminada.
    /// </summary>
    sealed partial class App : Application
    {
        public bool IsTrial { get; set; }
        public static int SelNota { get; set; }
        public static string SelMenu { get; set; }
        public static bool SecTile { get; set; }
        public static bool IsMenuVisible { get; set; }
        public static bool HasError { get; set; }
        
        public OneDriveService ServiceInstance
        {
            get;
            private set;
        }

        /// <summary>
        /// Inicializa el objeto de aplicación Singleton. Esta es la primera línea de código creado
        /// ejecutado y, como tal, es el equivalente lógico de main() o WinMain().
        /// </summary>
        public App()
        {
            Microsoft.ApplicationInsights.WindowsAppInitializer.InitializeAsync(
                Microsoft.ApplicationInsights.WindowsCollectors.Metadata |
                Microsoft.ApplicationInsights.WindowsCollectors.Session);

            this.InitializeComponent();
            this.Suspending += OnSuspending;
            
            // OneDrive Client ID
            ServiceInstance = new OneDriveService("0000000040110993"); //Mis Notas
        }

        /// <summary>
        /// Se invoca cuando el usuario final inicia la aplicación normalmente. Se usarán otros puntos
        /// de entrada cuando la aplicación se inicie para abrir un archivo específico, por ejemplo.
        /// </summary>
        /// <param name="e">Información detallada acerca de la solicitud y el proceso de inicio.</param>
        protected override void OnLaunched(LaunchActivatedEventArgs e)
        {
#if DEBUG
            if (System.Diagnostics.Debugger.IsAttached)
            {
                this.DebugSettings.EnableFrameRateCounter = false;
            }
#endif
            try
            {
                var li = Windows.ApplicationModel.Store.CurrentApp.LicenseInformation;
                IsTrial = li.IsTrial;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error al obtener el tipo de licencia: " + ex.Message);
            }

            //Se creará la tabla Notas, si no existe.
            using (var conn = new SQLiteConnection(new SQLitePlatformWinRT(), DbConnectionString))
            {
                conn.CreateTable<Nota>();

#if DEBUG
                Nota nota = new Nota();
                nota.Id = 1;
                nota.Asunto = "Welcome to MyNotes";
                nota.Fecha = DateTime.Now;
                nota.Detalle = "Welcome to MyNotes for Windows 10. Now MyNotes it's an UWP App, that's mean that you can run it in your Phone, Tablet and PC, under Windows 10. Enjoy it!";
                nota.FSize = 22;
                nota.CFondo = "#ED341D";

                var i = conn.InsertOrReplace(nota);


                nota.Id = 2;
                nota.Asunto = "Lorem ipsum";
                nota.Fecha = DateTime.Now;
                nota.Detalle = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Nullam quis lectus nisl. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Duis suscipit lobortis magna, nec varius turpis aliquet sit amet. Donec nunc nisl, faucibus nec tellus a, dignissim porttitor odio. Duis quis rhoncus orci. Morbi a suscipit nulla. Fusce tristique rutrum maximus. Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus eu turpis finibus, semper elit quis, rutrum erat. Curabitur ornare volutpat sapien eget mattis. Fusce bibendum ligula enim, sed facilisis nisl bibendum id. ";
                nota.FSize = 22;
                nota.CFondo = "#ED341D";

                i = conn.InsertOrReplace(nota);

                nota.Id = 3;
                nota.Asunto = "Nota 3";
                nota.Fecha = DateTime.Now;
                nota.Detalle = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse at quam pharetra, dictum lectus quis, mollis nunc. Nullam rhoncus, ligula eu ornare facilisis, tellus enim dignissim ligula, gravida tristique quam turpis eget odio. Sed egestas, turpis ut auctor scelerisque, ante risus molestie est, non tempor orci justo a dui. Sed id porta sapien. Praesent in eleifend magna, eget dignissim elit. Duis ut mauris id magna consectetur facilisis. Curabitur efficitur quis ex ut ullamcorper. Mauris laoreet, purus id dictum euismod, erat dolor cursus erat, nec pulvinar risus nisl et dui. Fusce eu tortor id lectus vulputate sodales ut eu magna. Mauris vehicula facilisis risus, sit amet maximus elit sodales non. Phasellus pulvinar a elit eget convallis. Nulla et elit vulputate dui euismod malesuada eget ac erat. Suspendisse efficitur vulputate lacinia. Donec libero augue, pulvinar et turpis et, vehicula aliquet velit. Donec egestas orci sit amet turpis posuere iaculis. Quisque sagittis pretium est, sit amet porta ante lacinia ac.Pellentesque placerat tortor et est imperdiet viverra.Maecenas blandit urna ut odio commodo feugiat.Sed a enim eu orci sollicitudin rutrum eu ac magna. Nullam eget eleifend tellus. Proin nec leo risus. Mauris metus lectus, tempus vel erat quis, condimentum bibendum leo. Suspendisse condimentum vehicula neque ac convallis. ";
                nota.FSize = 22;
                nota.CFondo = "#ED341D";

                i = conn.InsertOrReplace(nota);
#endif
            }

            App.HasError = false;
            Frame rootFrame = Window.Current.Content as Frame;

            // No repetir la inicialización de la aplicación si la ventana tiene contenido todavía,
            // solo asegurarse de que la ventana está activa.
            if (rootFrame == null)
            {
                // Crear un marco para que actúe como contexto de navegación y navegar a la primera página.
                rootFrame = new Frame();

                rootFrame.NavigationFailed += OnNavigationFailed;

                if (e.PreviousExecutionState == ApplicationExecutionState.Terminated)
                {
                    //TODO: Cargar el estado de la aplicación suspendida previamente
                }

                // Poner el marco en la ventana actual.
                Window.Current.Content = rootFrame;
            }

            if (e.PrelaunchActivated == false)
            {
                if (rootFrame.Content == null || e.TileId != "App")
                {
                    // Cuando no se restaura la pila de navegación, navegar a la primera página,
                    // configurando la nueva página pasándole la información requerida como
                    // parámetro de navegación
                    if (e.TileId != "App")
                    {
                        App.SelNota = Int32.Parse(e.TileId);
                        App.SecTile = true;
                        rootFrame.Content = null;
                        rootFrame.Navigate(typeof(Shell), e.TileId);
                    }
                    else
                    {
                        App.SecTile = false;
                        rootFrame.Navigate(typeof(Shell), e.Arguments);
                    }
                }
                
                // Asegurarse de que la ventana actual está activa.
                Window.Current.Activate();
            }


           InitializeLanguage();
        }

        /// <summary>
        /// Se invoca cuando la aplicación la inicia normalmente el usuario final. Se usarán otros puntos
        /// </summary>
        /// <param name="sender">Marco que produjo el error de navegación</param>
        /// <param name="e">Detalles sobre el error de navegación</param>
        void OnNavigationFailed(object sender, NavigationFailedEventArgs e)
        {
            throw new Exception("Failed to load Page " + e.SourcePageType.FullName);
        }

        /// <summary>
        /// Se invoca al suspender la ejecución de la aplicación. El estado de la aplicación se guarda
        /// sin saber si la aplicación se terminará o se reanudará con el contenido
        /// de la memoria aún intacto.
        /// </summary>
        /// <param name="sender">Origen de la solicitud de suspensión.</param>
        /// <param name="e">Detalles sobre la solicitud de suspensión.</param>
        private void OnSuspending(object sender, SuspendingEventArgs e)
        {
            var deferral = e.SuspendingOperation.GetDeferral();
            //TODO: Guardar el estado de la aplicación y detener toda actividad en segundo plano
            deferral.Complete();
        }



        public static string DbConnectionString
        {
            get
            {
                return Path.Combine(ApplicationData.Current.LocalFolder.Path, "Storage.sqlite");
            }
        }



        private void InitializeLanguage()
        {
            try
            {
                // Set the font to match the display language defined by the
                // "Idioma" resource string for each supported language.

                Frame rootFrame = Window.Current.Content as Frame;
                rootFrame.Language = Windows.ApplicationModel.Resources.ResourceLoader.GetForCurrentView().GetString("Idioma");
                System.Diagnostics.Debug.WriteLine("IDIOMA: " + rootFrame.Language);

                // Set the FlowDirection of all elements under the root frame based
                // on the ResourceFlowDirection resource string for each
                // supported language.
                //
                if (Windows.ApplicationModel.Resources.ResourceLoader.GetForCurrentView().GetString("ResourceFlowDirection") == "LeftToRight")
                {
                    rootFrame.FlowDirection = FlowDirection.LeftToRight;
                    System.Diagnostics.Debug.WriteLine("Sentido texto: LeftToRight");
                }
                else
                {
                    rootFrame.FlowDirection = FlowDirection.RightToLeft;
                    System.Diagnostics.Debug.WriteLine("Sentido texto: RightToLeft");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("Error al establecer el idioma: " + ex.Message);                
            }            

        }

        



    }
}
