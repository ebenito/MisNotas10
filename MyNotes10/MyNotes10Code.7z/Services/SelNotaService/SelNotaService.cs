﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace MyNotes10.Services.SelNotaService
//{
//    public class SelNotaService
//    {
//        public static SelNotaService Instance { get; } = new SelNotaService();
//        MyNotes10.Services.SelNotaService.ISelNotaService _helper;
//        private SelNotaService()
//        {
//            _helper = new MyNotes10.Services.SelNotaService.SelNotaService();
//        }

//    }
//}
