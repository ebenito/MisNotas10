﻿//using System;
//using System.Collections.Generic;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace MyNotes10.Services.SelNotaService
//{
    
//    public interface ISelNotaService
//    {
//        ISelNotaService Container(SettingsStrategies strategy);
//        bool Exists(string key, SettingsStrategies strategy = SettingsStrategies.Local);
//        T Read<T>(string key, T otherwise, SettingsStrategies strategy = SettingsStrategies.Local);
//        void Remove(string key, SettingsStrategies strategy = SettingsStrategies.Local);
//        void Write<T>(string key, T value, SettingsStrategies strategy = SettingsStrategies.Local);
//    }
//}
