﻿namespace MyNotes10.Services.DialogService
{
    public interface IDialogService 
    {
        void ShowMessage(string message, string header);
        bool ShowMessageYesNo(string message);
    }
}
