﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyNotes10.Services.LoaderService
{
    public interface ILoaderService
    {
        string getString(string key);
    }
}
