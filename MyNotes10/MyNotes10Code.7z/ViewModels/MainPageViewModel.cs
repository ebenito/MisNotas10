﻿using MyNotes10.Models;
using MyNotes10.Services.LoaderService;
using MyNotes10.Services.DialogService;
using MyNotes10.Services.NotaService;
using MyNotes10.ViewModels.Base;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Windows.System;
using Windows.UI.Xaml.Navigation;

namespace MyNotes10.ViewModels
{
    public class MainPageViewModel : ViewModelBase
    {

        #region Properties

        private ILoaderService _loaderService;
        private IDialogService _dialogService;
        private INotaService _notaService;
        private Nota auxNota = new Nota();

        public Nota AuxNota
        {
            get { return auxNota; }
            set
            {
                auxNota = value;
                App.SelNota = (auxNota != null) ? auxNota.Id : 0;
                RaisePropertyChanged();
            }
        }

        #endregion



        #region Collections

        private ObservableCollection<Nota> notaList;
        public ObservableCollection<Nota> NotaList
        {
            get { return notaList; }
            set
            {
                notaList = value;
                RaisePropertyChanged();
            }
        }

        #endregion




        #region Methods

        public MainPageViewModel(IDialogService dialogService, INotaService notaService, ILoaderService loaderService)
        {
            _dialogService = dialogService;
            _notaService = notaService;
            _loaderService = loaderService;
        }
        public override Task OnNavigatedFrom(NavigationEventArgs args)
        {
            return null;
        }
        public override Task OnNavigatedTo(NavigationEventArgs args)
        {
            if (args.Parameter != null)
            {
                if (args.Parameter.ToString() == "Backup")
                {
                    //_dialogService.ShowMessage("Coming soon.", "My Notes");
                    App.SelMenu = "Backup";
                }
            }

            RefreshListNota();
            return null;
        }

        private void RefreshListNota()
        {
            NotaList = new ObservableCollection<Nota>(_notaService.GetNotas());
            ClearNota();
        }
        private void ClearNota()
        {
            AuxNota = null;
            AuxNota = new Nota();
        }

        #endregion




        #region Commands

        private DelegateCommand insertOrUpdateNotaCommand;
        private DelegateCommand newNotaCommand;
        private DelegateCommand deleteNotaCommand;
        
        private DelegateCommand<string> _TextoABuscarCommand;
        //private DelegateCommand<string> _TraduceCadenaCommand;
       // private DelegateCommand<string> _CambiaIdiomaCommand;

        private DelegateCommand openStoreCommand;


        public ICommand InsertOrUpdateNotaCommand
        {
            get { return insertOrUpdateNotaCommand = insertOrUpdateNotaCommand ?? new DelegateCommand(insertOrUpdateNotaCommandExecute); }
        }
        public ICommand NewNotaCommand
        {
            get { return newNotaCommand = newNotaCommand ?? new DelegateCommand(newNotaCommandExecute); }
        }
        public ICommand DeleteNotaCommand
        {
            get { return deleteNotaCommand = deleteNotaCommand ?? new DelegateCommand(deleteNotaCommandExecute); }
        }
        public ICommand OpenStoreCommand
        {
            get { return openStoreCommand = openStoreCommand ?? new DelegateCommand(openStoreCommandExecute); }
        }


        private void insertOrUpdateNotaCommandExecute()
        {
            _notaService.InsertOrUpdateNota(auxNota);
            RefreshListNota();
        }
        private void newNotaCommandExecute()
        {
            ClearNota();
        }
        private void deleteNotaCommandExecute()
        {
            _notaService.DeleteNota(AuxNota);
            RefreshListNota();
        }

        public ICommand TextoABuscarCommand
        {
            get { return _TextoABuscarCommand = _TextoABuscarCommand ?? new DelegateCommand<string>(TextoABuscarCommandExecute); }
        }

        private void TextoABuscarCommandExecute(string busca)
        {
            NotaList = new ObservableCollection<Nota>(_notaService.SearchNotas(busca));
            ClearNota();
        }


        //public ICommand TraduceCadenaCommand
        //{
        //    get { return _TraduceCadenaCommand = _TraduceCadenaCommand ?? new DelegateCommand<string>(TraduceCadenaCommandExecute); }
        //}
        //private void TraduceCadenaCommandExecute(string cadena)
        //{
        //    _dialogService.ShowMessage(_loaderService.getString(cadena),"Cap");
        //}


        //public ICommand CambiaIdioma
        //{
        //    get { return _CambiaIdiomaCommand = _CambiaIdiomaCommand ?? new DelegateCommand<string>(CambiaIdiomaCommandExecute); }
        //}
        //private async void CambiaIdiomaCommandExecute(string newLang)
        //{
        //    var resourceContext = Windows.ApplicationModel.Resources.Core.ResourceContext.GetForCurrentView();

        //    while (true)
        //    {
        //        if (resourceContext.Languages[0] == newLang)
        //        {
        //            Windows.Globalization.ApplicationLanguages.PrimaryLanguageOverride = "en-US";
        //            Windows.UI.Xaml.Controls.Frame.Navigate(this.GetType());
        //            break;
        //        }
        //        await Task.Delay(100);
        //    }
        //}


        private async void openStoreCommandExecute()
        {
            await openStore();
        }

        public async Task openStore()
        {
            //const string productId = "9NBLGGH4RP1N";  //MyNotes10
            const string productId = "9NBLGGH08MCR"; //My Notes
            var uri = new Uri("ms-windows-store://review/?ProductId=" + productId);
            await Launcher.LaunchUriAsync(uri);
        }


        #endregion




    }
}
