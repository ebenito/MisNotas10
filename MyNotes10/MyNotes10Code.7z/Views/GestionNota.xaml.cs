﻿using MyNotes10.ViewModels;
using MyNotes10.Views.Base;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using System.Threading.Tasks;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.Media.SpeechRecognition;
using Windows.Media.SpeechSynthesis;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en http://go.microsoft.com/fwlink/?LinkId=234238

namespace MyNotes10.Views
{
    /// <summary>
    /// Una página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class GestionNota : PageBase
    {
        public GestionNota()
        {
            this.InitializeComponent();
            this.Loaded += GestionNota_Loaded;
            //if (App.SelNota == 0)
            //{
            //    T_Accion.Text = "Nuevo";
            //}
            //else
            //{
            //    T_Accion.Text = "Edita nota ID " + App.SelNota;
            //}
        }

        private void GestionNota_Loaded(object sender, RoutedEventArgs e)
        {
            if (App.HasError)
            {
                App.HasError = false; //Reseteo la variable
                this.Frame.Navigate(typeof(MainPage));
            }
        }

        private void PageBase_Loading(FrameworkElement sender, object args)
        {
            //http://www.iteramos.com/pregunta/18658/mvvm-locura-comandos
            //GestionNotaViewModel vm = this.DataContext as GestionNotaViewModel;
            //if (vm == null) return; //Check if conversion succeeded

            //if (App.SelNota == 0)
            //{
            //    vm.MsgAccionActual = "Nuevo";
            //}
            //else
            //{
            //    vm.MsgAccionActual = "Edita nota ID " + App.SelNota;
            //}            
        }

        private void AppBarButton_Click(object sender, RoutedEventArgs e)
        {
            if (Frame.CanGoBack)
            {
                Frame.GoBack();
            }
        }

        private void pageBase_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            try
            {
                T_Alto.Text = pageBase.ActualHeight.ToString();
                System.Diagnostics.Debug.WriteLine($"Alto: {pageBase.ActualHeight.ToString()}");
                System.Diagnostics.Debug.WriteLine($"Ancho: {pageBase.ActualWidth.ToString()}");

                if (pageBase.ActualWidth < 400)
                {
                    cmdBtnBack.Visibility = Visibility.Collapsed;
                }
                else
                {
                    cmdBtnBack.Visibility = Visibility.Visible;
                }
            }
            catch
            {
                T_Alto.Text = "400";
            }
        }
        

        async Task<string> RecordSpeechFromMicrophoneAsync()
        {
            string recognizedText = string.Empty;

            using (SpeechRecognizer recognizer =
              new Windows.Media.SpeechRecognition.SpeechRecognizer())
            {
                await recognizer.CompileConstraintsAsync();

                SpeechRecognitionResult result = await recognizer.RecognizeAsync();

                if (result.Status == SpeechRecognitionResultStatus.Success)
                {
                    recognizedText = result.Text;
                }
            }
            return (recognizedText);
        }

        private async void Btn_Audio_Click(object sender, RoutedEventArgs e)
        {
            SpeechSynthesizer reader = new SpeechSynthesizer();
            await reader.SynthesizeTextToStreamAsync("This is my first speech project");

        }
    }
}
