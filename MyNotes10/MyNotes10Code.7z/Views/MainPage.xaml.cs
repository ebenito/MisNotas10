﻿using MyNotes10.Models;
using MyNotes10.ViewModels;
using MyNotes10.ViewModels.Base;
using MyNotes10.Views.Base;
using OneDriveSimple;
using OneDriveSimple.Helpers;
using OneDriveSimple.Response;
using SQLite.Net;
using SQLite.Net.Platform.WinRT;
using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Core;
using Windows.UI.Popups;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;

// La plantilla de elemento Página en blanco está documentada en http://go.microsoft.com/fwlink/?LinkId=234238

namespace MyNotes10.Views
{
    /// <summary>
    /// Una página vacía que se puede usar de forma independiente o a la que se puede navegar dentro de un objeto Frame.
    /// </summary>
    public sealed partial class MainPage : PageBase
    {        
        private MenuItem myItem;
        
        public MainPage()
        {
            this.InitializeComponent();
            this.SizeChanged += MainPage_SizeChanged;            
        }
        
        private void MainPage_SizeChanged(object sender, SizeChangedEventArgs e)
        {
            if (App.IsMenuVisible)
            {
                Separar.Width = 50;
            }
            else
            {
                Separar.Width = 0;
            }

        }

        private void CreaMenu()
        {
            if ((this.DataContext as ViewModelBase).Menu.Count != 0)
            {
                (this.DataContext as ViewModelBase).Menu.Clear();
            }
            
            myItem = new MenuItem() { Glyph = "", Text = traduce("MenuTodasNotas"), NavigationDestination = typeof(MainPage) };
            (this.DataContext as ViewModelBase).Menu.Add(myItem);

            myItem = new MenuItem() { Glyph = "", Text = traduce("MenuNueva"), NavigationDestination = typeof(GestionNota), Param = "New" };
            (this.DataContext as ViewModelBase).Menu.Add(myItem);

            myItem = new MenuItem() { Glyph = "", Text = traduce("MenuEditar"), NavigationDestination = typeof(GestionNota), Param = "Edit" };
            (this.DataContext as ViewModelBase).Menu.Add(myItem);

            myItem = new MenuItem() { Glyph = "", Text = traduce("MenuBackup"), NavigationDestination = typeof(BackupOneDrive), Param = "Backup" };
            (this.DataContext as ViewModelBase).Menu.Add(myItem);

            myItem = new MenuItem() { Glyph = "", Text = traduce("MenuValorar"), Command = (DataContext as MainPageViewModel).OpenStoreCommand };
            (this.DataContext as ViewModelBase).Menu.Add(myItem);

            myItem = new MenuItem() { Glyph = "", Text = "Language", NavigationDestination = typeof(Seldioma) };
            (this.DataContext as ViewModelBase).Menu.Add(myItem);
        }

        string traduce(string cadena)
        {
            var loader = new Windows.ApplicationModel.Resources.ResourceLoader();
            var str = loader.GetString(cadena);
            return str;
        }

        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
            CreaMenu();
            base.OnNavigatedTo(e);
        }

        protected override void OnNavigatedFrom(NavigationEventArgs e)
        {
            var query = (this.DataContext as ViewModelBase).Menu.Select((menu, index) =>
                                                                new { index, str = menu });

            foreach (var obj in query)
            {
                System.Diagnostics.Debug.WriteLine("{0}", obj.str);
            }
                      
            base.OnNavigatedFrom(e);
        }

    }
}
